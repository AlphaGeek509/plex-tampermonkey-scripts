// src/quote-tracking/qt35-attachmentsGet/qt35.index.js

(() => {
    'use strict';

    const DEV = (typeof __BUILD_DEV__ !== 'undefined') ? __BUILD_DEV__ : true;
    const dlog = (...a) => DEV && console.debug('QT35', ...a);
    const derr = (...a) => console.error("QT35 ✖️", ...a);
    const ROOT = (typeof unsafeWindow !== 'undefined' ? unsafeWindow : window);
    // Use global withFreshAuth if present; otherwise a no-op wrapper
    const __withFreshAuth = (typeof withFreshAuth === 'function') ? withFreshAuth : async (fn) => await fn();

    (async () => {
        // ensureLTDock is provided by @require’d lt-ui-dock.js
        const dock = await window.ensureLTDock?.();
        dock?.register({
            id: 'qt35-attachments',
            label: 'Attachments',
            title: 'Open QT35 Attachments',
            weight: 120,
            onClick: () => openAttachmentsModal()
        });
    })();


    const ROUTES = [/^\/SalesAndCRM\/QuoteWizard(?:\/|$)/i];
    if (!ROUTES.some(rx => rx.test(location.pathname))) return;

    const KO = (typeof unsafeWindow !== 'undefined' ? unsafeWindow.ko : window.ko);
    const raf = () => new Promise(r => requestAnimationFrame(r));

    const CFG = {
        ACTION_BAR_SEL: '#QuoteWizardSharedActionBar',
        GRID_SEL: '.plex-grid',
        SHOW_ON_PAGES_RE: /review|summary|submit/i,
        DS_ATTACHMENTS_BY_QUOTE: 11713,
        ATTACHMENT_GROUP_KEY: 11,
        DS_QUOTE_HEADER_GET: 3156,
        POLL_MS: 200,
        TIMEOUT_MS: 12_000
    };

    // === Per-tab scope id (same as QT10) ===
    function findDC(win = (typeof unsafeWindow !== 'undefined' ? unsafeWindow : window)) {
        try { if (win.lt?.core?.data) return win.lt.core.data; } catch { }
        for (let i = 0; i < win.frames.length; i++) {
            try { const dc = findDC(win.frames[i]); if (dc) return dc; } catch { }
        }
        return null;
    }


    function getTabScopeId(ns = 'QT') {
        try {
            const k = `lt:${ns}:scopeId`;
            let v = sessionStorage.getItem(k);
            if (!v) {
                v = String(Math.floor(Math.random() * 2147483647));
                sessionStorage.setItem(k, v);
            }
            return Number(v);
        } catch {
            return Math.floor(Math.random() * 2147483647);
        }
    }

    function getActiveWizardPageName() {
        const active = document.querySelector('.plex-wizard-page.active, .plex-wizard-page[aria-current="page"]');
        if (active) {
            try {
                const vm = KO?.dataFor?.(active);
                const name = vm ? (window.TMUtils?.getObsValue?.(vm, 'Name') || window.TMUtils?.getObsValue?.(vm, 'name')) : '';
                if (name) return String(name);
            } catch { }
        }
        const h = document.querySelector('.wizard-header, .plex-page h1, h1');
        if (h?.textContent) return h.textContent.trim();
        const nav = document.querySelector('.plex-wizard-page-list .active, .plex-wizard-page-list [aria-current="page"]');
        return (nav?.textContent || '').trim();
    }
    function isOnTargetWizardPage() { return CFG.SHOW_ON_PAGES_RE.test(getActiveWizardPageName() || ''); }

    async function ensureWizardVM() {
        const anchor = document.querySelector(CFG.GRID_SEL) ? CFG.GRID_SEL : CFG.ACTION_BAR_SEL;
        const { viewModel } = await (window.TMUtils?.waitForModelAsync(anchor, { pollMs: CFG.POLL_MS, timeoutMs: CFG.TIMEOUT_MS, requireKo: true }) ?? { viewModel: null });
        return viewModel;
    }

    function getQuoteKeyDeterministic() {
        try {
            const grid = document.querySelector(CFG.GRID_SEL);
            if (grid && KO?.dataFor) {
                const gridVM = KO.dataFor(grid);
                const raw0 = Array.isArray(gridVM?.datasource?.raw) ? gridVM.datasource.raw[0] : null;
                const v = raw0 ? window.TMUtils?.getObsValue?.(raw0, 'QuoteKey') : null;
                if (v != null) return Number(v);
            }
        } catch { }
        try {
            const rootEl = document.querySelector('.plex-wizard, .plex-page');
            const rootVM = rootEl ? KO?.dataFor?.(rootEl) : null;
            const v = rootVM && (window.TMUtils?.getObsValue?.(rootVM, 'QuoteKey') || window.TMUtils?.getObsValue?.(rootVM, 'Quote.QuoteKey'));
            if (v != null) return Number(v);
        } catch { }
        const m = /[?&]QuoteKey=(\d+)/i.exec(location.search);
        return m ? Number(m[1]) : null;
    }

    // ===== Repo via lt-data-core flat {header, lines} =====
    function peekDC() {
        const DC = findDC();
        return DC && DC.createDataContext && DC.makeFlatScopedRepo ? DC : null;
    }

    let quoteRepo = null, lastScope = null;
    let __QT__ = null;

    function tryGetQT() {
        const DC = peekDC();
        if (!DC) return null;
        if (!__QT__) __QT__ = DC.makeFlatScopedRepo({ ns: 'QT', entity: 'quote', legacyEntity: 'QuoteHeader' });
        return __QT__;
    }

    async function ensureRepoForQuote(quoteKey) {
        const QTF = tryGetQT();
        if (!QTF) return null;
        const { ctx, repo } = QTF.use(Number(quoteKey));
        quoteRepo = repo;                 // <-- persist for later callers
        lastScope = Number(quoteKey);     // <-- track scope we’re bound to
        await repo.ensureFromLegacyIfMissing?.();
        return repo;
    }



    // Background promotion (per-tab draft -> per-quote) with gentle retries
    const __PROMOTE = { timer: null, tries: 0, max: 120, intervalMs: 250 };

    function schedulePromoteDraftToQuote(quoteKey) {
        if (__PROMOTE.timer) return;
        __PROMOTE.timer = setInterval(async () => {
            try {
                const QTF = tryGetQT();
                const repoQ = await ensureRepoForQuote(quoteKey);
                if (!QTF || !repoQ) { if (++__PROMOTE.tries >= __PROMOTE.max) stopPromote(); return; }

                // Read the SAME per-tab draft scope QT10 writes to
                const { repo: draftRepo } = QTF.use(getTabScopeId('QT'));
                const draft = await (draftRepo.getHeader?.() || draftRepo.get());
                if (draft && Object.keys(draft).length) {
                    await repoQ.patchHeader({
                        Quote_Key: Number(quoteKey),
                        Customer_No: draft.Customer_No ?? null,
                        Catalog_Key: draft.Catalog_Key ?? null,
                        Catalog_Code: draft.Catalog_Code ?? null,
                        Promoted_From: 'draft',
                        Promoted_At: Date.now(),
                        Quote_Header_Fetched_At: null,
                        Updated_At: draft.Updated_At || Date.now(),
                    });
                    await draftRepo.clear?.();
                    try { const { repo: legacy } = QTF.use('draft'); await legacy.clear?.(); } catch { }

                }
                stopPromote();
            } catch {
                // keep retrying
            }
        }, __PROMOTE.intervalMs);
    }

    function stopPromote() {
        clearInterval(__PROMOTE.timer);
        __PROMOTE.timer = null;
        __PROMOTE.tries = 0;
    }


    // ===== Merge QT10 draft → per-quote (once) =====
    // ===== Merge QT10 draft → per-quote (once) =====
    async function mergeDraftIntoQuoteOnce(qk) {
        if (!qk || !Number.isFinite(qk) || qk <= 0) return;

        const QTF = tryGetQT();
        if (!QTF) { schedulePromoteDraftToQuote(qk); return; }

        // Read per-tab draft (same scope QT10 writes to)
        const { repo: draftRepo } = QTF.use(getTabScopeId('QT'));
        const draft = await draftRepo.getHeader?.() || await draftRepo.get(); // tolerate legacy
        if (!draft) return;

        await ensureRepoForQuote(qk);
        if (!quoteRepo) return; // DC not ready yet

        const currentHeader = (await quoteRepo.getHeader()) || {};
        const curCust = String(currentHeader.Customer_No ?? '');
        const newCust = String(draft.Customer_No ?? '');

        const needsMerge =
            (Number((await draftRepo.get())?.Updated_At || 0) > Number(currentHeader.Promoted_At || 0)) ||
            (curCust !== newCust) ||
            (currentHeader.Catalog_Key !== draft.Catalog_Key) ||
            (currentHeader.Catalog_Code !== draft.Catalog_Code);

        if (!needsMerge) return;

        await quoteRepo.patchHeader({
            Quote_Key: Number(qk),
            Customer_No: draft.Customer_No ?? null,
            Catalog_Key: draft.Catalog_Key ?? null,
            Catalog_Code: draft.Catalog_Code ?? null,
            Promoted_From: 'draft',
            Promoted_At: Date.now(),
            // force re-hydration next time
            Quote_Header_Fetched_At: null
        });

        // clear per-tab draft and legacy if present
        await draftRepo.clear?.();
        try { const { repo: legacy } = QTF.use('draft'); await legacy.clear?.(); } catch { }


        dlog('Draft merged (flat repo header updated)', { qk });
    }



    // ===== Data sources =====
    async function fetchAttachmentCount(quoteKey) {
        const plex = (typeof getPlexFacade === "function") ? await getPlexFacade() : (ROOT.lt?.core?.plex);
        if (!plex?.dsRows) return 0;
        const rows = await __withFreshAuth(() => plex.dsRows(CFG.DS_ATTACHMENTS_BY_QUOTE, {
            Attachment_Group_Key: CFG.ATTACHMENT_GROUP_KEY,
            Record_Key_Value: String(quoteKey)
        }));
        return Array.isArray(rows) ? rows.length : 0;
    }

    function quoteHeaderGet(row) {
        return {
            Customer_Code: row?.Customer_Code ?? null,
            Customer_Name: row?.Customer_Name ?? null,
            Customer_No: row?.Customer_No ?? null,
            Quote_No: row?.Quote_No ?? null
        };
    }
    async function hydratePartSummaryOnce(qk) {
        await ensureRepoForQuote(qk);
        if (!quoteRepo) return;
        const headerSnap = (await quoteRepo.getHeader()) || {};
        if (headerSnap.Quote_Header_Fetched_At) return;

        const plex = (typeof getPlexFacade === "function" ? await getPlexFacade() : ROOT.lt?.core?.plex);
        if (!plex?.dsRows) return;
        const rows = await __withFreshAuth(() => plex.dsRows(CFG.DS_QUOTE_HEADER_GET, { Quote_Key: String(qk) }));

        const first = (Array.isArray(rows) && rows.length) ? quoteHeaderGet(rows[0]) : null;
        if (!first) return;

        await quoteRepo.patchHeader({ Quote_Key: qk, ...first, Quote_Header_Fetched_At: Date.now() });
    }

    // ===== UI badge =====
    const LI_ID = 'lt-attachments-badge';
    const PILL_ID = 'lt-attach-pill';

    function ensureBadge() {
        const bar = document.querySelector(CFG.ACTION_BAR_SEL);
        if (!bar || bar.tagName !== 'UL') return null;

        const existing = document.getElementById(LI_ID);
        if (existing) return existing;

        const li = document.createElement('li'); li.id = LI_ID;
        const a = document.createElement('a'); a.href = 'javascript:void(0)'; a.title = 'Refresh attachments (manual)';
        const pill = document.createElement('span'); pill.id = PILL_ID;
        Object.assign(pill.style, { display: 'inline-block', minWidth: '18px', padding: '2px 8px', borderRadius: '999px', textAlign: 'center', fontWeight: '600' });

        a.appendChild(document.createTextNode('Attachments '));
        a.appendChild(pill);
        li.appendChild(a);
        bar.appendChild(li);

        a.addEventListener('click', () => runOneRefresh(true));
        return li;
    }
    function setBadgeCount(n) {
        const pill = document.getElementById(PILL_ID);
        if (!pill) return;
        pill.textContent = String(n ?? 0);
        const isZero = !n || n === 0;
        pill.style.background = isZero ? '#e5e7eb' : '#10b981';
        pill.style.color = isZero ? '#111827' : '#fff';
    }

    let refreshInFlight = false;
    async function runOneRefresh(manual = false) {
        if (refreshInFlight) return;
        refreshInFlight = true;
        try {
            await ensureWizardVM();
            const qk = getQuoteKeyDeterministic();
            if (!qk || !Number.isFinite(qk) || qk <= 0) {
                setBadgeCount(0);
                if (manual) window.TMUtils?.toast?.('⚠️ Quote Key not found', 'warn', 2200);
                return;
            }

            // If scope changed, paint any existing snapshot before fetching
            if (!quoteRepo || lastScope !== qk) {
                await ensureRepoForQuote(qk);
                try {
                    const head = await quoteRepo?.getHeader?.();
                    if (head?.Attachment_Count != null) setBadgeCount(Number(head.Attachment_Count));
                } catch { }
            }

            // Promote & clear draft BEFORE per-quote updates
            await mergeDraftIntoQuoteOnce(qk);

            // If DC isn't ready yet, skip quietly; the observer/next click will retry
            if (!quoteRepo) return;

            const count = await fetchAttachmentCount(qk);
            setBadgeCount(count);
            await quoteRepo.patchHeader({ Quote_Key: qk, Attachment_Count: Number(count) });

            if (manual) {
                const ok = count > 0;
                window.TMUtils?.toast?.(ok ? `✅ ${count} attachment(s)` : '⚠️ No attachments', ok ? 'success' : 'warn', 2000);
            }
            dlog('refresh', { qk, count });
        } catch (err) {
            derr('refresh failed', err);
            window.TMUtils?.toast?.(`❌ Attachments refresh failed: ${err?.message || err}`, 'error', 4000);
        } finally {
            refreshInFlight = false;
        }
    }


    // ===== SPA wiring =====
    let booted = false; let offUrl = null;
    function wireNav(handler) { offUrl?.(); offUrl = window.TMUtils?.onUrlChange?.(handler); }

    async function init() {
        if (booted) return;
        booted = true;
        await raf();

        const li = ensureBadge();
        if (!li) return;
        startWizardPageObserver();

        const show = isOnTargetWizardPage();
        li.style.display = show ? '' : 'none';

        if (show) {
            await ensureWizardVM();

            const qk = getQuoteKeyDeterministic();
            schedulePromoteDraftToQuote(qk);

            if (qk && Number.isFinite(qk) && qk > 0) {
                await ensureRepoForQuote(qk);
                await mergeDraftIntoQuoteOnce(qk);
                await runOneRefresh(false);
                try { await hydratePartSummaryOnce(qk); } catch (e) { console.error('QT35 hydrate failed', e); }
            }
        }
        dlog('initialized');
    }
    function teardown() {
        booted = false;
        offUrl?.();
        offUrl = null;
        stopWizardPageObserver();
    }

    init();

    // Place near other module-level lets
    let lastWizardPage = null;
    let pageObserver = null;

    function startWizardPageObserver() {
        const root = document.querySelector('.plex-wizard') || document.body;
        lastWizardPage = getActiveWizardPageName();
        pageObserver?.disconnect();
        pageObserver = new MutationObserver(() => {
            const name = getActiveWizardPageName();
            if (name !== lastWizardPage) {
                lastWizardPage = name;
                if (isOnTargetWizardPage()) {
                    queueMicrotask(async () => {
                        const qk = getQuoteKeyDeterministic();
                        if (qk && Number.isFinite(qk) && qk > 0) {
                            await ensureRepoForQuote(qk);
                            await mergeDraftIntoQuoteOnce(qk);
                            await runOneRefresh(false);
                            try { await hydratePartSummaryOnce(qk); } catch { }
                        }
                    });
                }
            }
        });
        pageObserver.observe(root, { attributes: true, childList: true, subtree: true, attributeFilter: ['class', 'aria-current'] });
    }

    function stopWizardPageObserver() {
        pageObserver?.disconnect();
        pageObserver = null;
    }

    wireNav(() => { if (ROUTES.some(rx => rx.test(location.pathname))) init(); else teardown(); });

})();
